import time
import pickle
import pandas as pd
from model_lib.main import population
import copy
import random


df = pd.read_csv("data/bnb_train_clean.csv")

AI = population('config.ini', 1000)
AI.add_inputs(26)
AI.add_layer(12)
AI.add_layer(10)
AI.add_layer(8)
AI.add_layer(6)
AI.add_layer(4)
AI.add_layer(2)
AI.add_outputs(1)
fitness = 0
goal = 95
best_of_all = -1

def ratio_of_ones_to_zeros(lst):
    ones_count = lst.count(1)
    zeros_count = lst.count(0)

    ratio = (max(ones_count, zeros_count) /len(lst)) * 100
    return ratio


while fitness < goal:
    start_row = random.randint(20, df.shape[0] - 120)
    for z in AI.bots:
            z.fitness =0
    for i in range(100):
        answer = df.loc[start_row + 1 + i, "trend"]
        data = df[['lockPrice', 'closePrice', 'totalAmount', 'up', 'down', 'up_reward', 'down_reward', 'trend', 'majority', 'majority_right', 'minute', 'streak_up', 'streak_down']].iloc[start_row-2+i:start_row+i].values.flatten().tolist()
        AI.active(*data)

        for z in AI.bots:
            z.prediction.append(z.final_output[0])
            if z.final_output[0] == answer:
                z.fitness+=1

    for k in AI.bots:
        ratio = ratio_of_ones_to_zeros(k.prediction)
        if ratio > 75:
            k.fitness = int(100 - ratio)
        k.prediction = []

    best , index , fitness = AI.best_bot()
    if fitness > best_of_all:
        with open(f'models/best_model_{fitness}.pkl', 'wb') as file:
            pickle.dump(best, file)

        best_of_all = fitness

    if fitness != 0:
        for b in range(len(AI.bots)):
            AI.bots[b] = copy.deepcopy(best)

    if fitness < goal:
        for l in range(2):
            AI.mutate()

    print(fitness)


