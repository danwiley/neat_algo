import numpy as np

# Activation functions
def abs_activation(x):
    return np.abs(x)

def clamped_activation(x):
    return np.clip(x, -1, 1)

def hat_activation(x):
    return np.maximum(0, 1 - np.abs(x))

def identity_activation(x):
    return x

def relu_activation(x):
    return np.maximum(0, x)

def binary_activation(x):
    return 0 if x <= 0 else 1



# Aggregation functions
def sum_aggregation(values):
    return np.sum(values)

def product_aggregation(values):
    return np.prod(values)

def min_aggregation(values):
    return np.min(values)

def max_aggregation(values):
    return np.max(values)

def mean_aggregation(values):
    return np.mean(values)



'''
# Example usage
inputs = -10

# Dynamically call the activation function
activation_function_name = "abs"
activation_function = activations[activation_function_name]
print(f"{activation_function_name} activation:", activation_function(inputs))

'''