import random
from .plot import plot_ai
from .Activation_Aggregation import *
import configparser

class neural_network:
    def __init__(self,config_file):
        self.nodes = []
        self.connections = []

        self.num_inputs = 0
        self.num_outputs = 0


        self.node_counter = 0
        self.connections_counter = 0

        self.final_output = 0

        self.fitness = 0
        self.prediction = []
        #--------------------------------- comfig
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        self.bias_max_value = float(self.config['bias']['bias_max_value'])
        self.bias_min_value = float(self.config['bias']['bias_min_value'])

        self.weight_max_value = float(self.config['weight']['weight_max_value'])
        self.weight_min_value = float(self.config['weight']['weight_min_value'])

        self.output_activations = self.config['activation']['output_activations'].split()

        self.aggregation_mutate_rate = float(self.config['aggregation']['aggregation_mutate_rate'])
        self.activation_mutate_rate = float(self.config['activation']['activation_mutate_rate'])

        self.bias_mutate_rate = float(self.config['bias']['bias_mutate_rate'])
        self.bias_mutate_power = float(self.config['bias']['bias_mutate_power'])
        self.bias_replace_rate = float(self.config['bias']['bias_replace_rate'])

        self.weight_mutate_rate = float(self.config['weight']['weight_mutate_rate'])
        self.weight_mutate_power = float(self.config['weight']['weight_mutate_power'])
        self.weight_replace_rate = float(self.config['weight']['weight_replace_rate'])

        self.node_add_prob = float(self.config['node']['node_add_prob'])
        self.node_delete_prob = float(self.config['node']['node_delete_prob'])

        self.conn_add_prob = float(self.config['connection']['conn_add_prob'])
        self.conn_delete_prob = float(self.config['connection']['conn_delete_prob'])


        # --------------------------------- comfig

        self.activations = {
            key: value for key, value in {
                "abs": abs_activation,
                "clamped": clamped_activation,
                "hat": hat_activation,
                "identity": identity_activation,
                "relu": relu_activation,
                "binary":binary_activation
            }.items() if key in self.config['activation']['activation_options']
        }


        self.aggregations = {
            key: value for key, value in {
                "sum": sum_aggregation,
                "product": product_aggregation,
                "min": min_aggregation,
                "max": max_aggregation,
                "mean": mean_aggregation
            }.items() if key in self.config['aggregation']['aggregation_options']
        }




    def plot(self):
        plot_ai(self.nodes, self.connections)

    def add_inputs(self, num_inputs):
        self.num_inputs = num_inputs
        self.nodes.append([])

        for i in range(num_inputs):
            self.node_counter += 1

            self.nodes[-1].append( {
                "layer": len(self.nodes),
                "id": self.node_counter,
                "value": 0
            })

    def add_layer(self, nodes):
        self.nodes.append([])
        for i in range(nodes):
            self.node_counter += 1

            self.nodes[-1].append( {
                "bias": random.uniform(self.bias_min_value,self.bias_max_value),
                "activation": (random.choice(list(self.activations)) if  self.output_activations == ["random"] or self.num_outputs==0 else self.output_activations[i]),
                "aggregation": random.choice(list(self.aggregations)),
                "layer": len(self.nodes),
                "id": self.node_counter,
                "value": 0

            })

    def add_outputs(self, num_outputs):
        self.num_outputs = num_outputs
        self.add_layer(num_outputs)
        self.set_connections()

    def set_connections(self):
        for layer_index in range(len(self.nodes) - 1):  # iterate over layers except the last one
            current_layer = self.nodes[layer_index]
            next_layer = self.nodes[layer_index + 1]
            for node in current_layer:
                for next_node in next_layer:
                    self.connections.append({"from": node['id'], "to": next_node['id'], "weight": random.uniform(self.weight_min_value,self.weight_max_value)})

    def get_value_by_id(self, target_id):
        for layer in self.nodes:
            for node in layer:
                if node.get('id') == target_id:
                    return node.get('value')
        return None

    def clean(self):
        self.final_output = 0
        for x in self.nodes:
            for y in x:
                y["value"] = 0

    def active(self, *args):
        if len(args) != self.num_inputs:
            return "args and input dont match"
        else:

            #clean old data
            self.clean()
            #set inputs
            for z,i in enumerate(self.nodes[0]):
                i["value"] = args[z]

            for x in self.nodes[1:]:
                for y in x:
                    temp_inputs = []
                    for z in self.connections:
                        if y["id"] == z["to"]:
                            temp_inputs.append(self.get_value_by_id(z["from"]) * z["weight"])


                    y["value"] = self.activations[y["activation"]]( (self.aggregations[y["aggregation"]](temp_inputs)) + y["bias"])

            self.final_output = [node['value'] for node in self.nodes[-1]]



    def mutate(self):

        #mutate activations
        for x in (self.nodes[1:] if self.output_activations == ["random"] else self.nodes[1:-1]):
            for y in x:
                if random.uniform(0,1) <= self.activation_mutate_rate:
                    y["activation"] = random.choice(list(self.activations))


        for x in (self.nodes[1:]):
            for y in x:
                # mutate aggregation
                if random.uniform(0,1) <= self.aggregation_mutate_rate:
                    y["aggregation"] = random.choice(list(self.aggregations))

                # mutate bias
                temp_bias_randomizer = random.uniform(0,1)
                if temp_bias_randomizer <= self.bias_replace_rate:
                    y["bias"] = random.uniform(self.bias_min_value,self.bias_max_value)
                elif temp_bias_randomizer <= self.bias_mutate_rate:
                    temp_bias = y["bias"] + ((random.uniform(self.bias_min_value,self.bias_max_value) - y["bias"]) * self.bias_mutate_power)
                    y["bias"] =  max(self.bias_min_value, min(temp_bias, self.bias_max_value))

        # mutate weight
        for x in self.connections:
            temp_weight_randomizer = random.uniform(0, 1)

            if temp_weight_randomizer <= self.weight_replace_rate:
                x["weight"] = random.uniform(self.weight_min_value,self.weight_max_value)
            elif temp_weight_randomizer <= self.weight_mutate_rate:
                temp_weight = x["weight"] + ((random.uniform(self.weight_min_value,self.weight_max_value) - x["weight"]) * self.weight_mutate_power)

                x["weight"] = max(self.weight_min_value, min(temp_weight, self.weight_max_value))

        #add node
        if random.uniform(0,1) <= self.node_add_prob:
            layer = random.randint(2,len(self.nodes)-1)

            current_id = self.nodes[-1][-1]["id"]+1
            self.nodes[layer-1].append({
                "bias": random.uniform(self.bias_min_value,self.bias_max_value),
                "activation": random.choice(list(self.activations)),
                "aggregation": random.choice(list(self.aggregations)),
                "layer": layer,
                "id": current_id,
                "value": 0
            })
            self.connections.append({"from": current_id, "to": random.choice([entry['id'] for entry in self.nodes[layer]]),"weight": random.uniform(self.weight_min_value, self.weight_max_value)})
            self.connections.append({"from": random.choice([entry['id'] for entry in self.nodes[layer-2]]), "to": current_id,"weight": random.uniform(self.weight_min_value, self.weight_max_value)})
            self.clean_ids()

        #remove node
        if random.uniform(0,1) <= self.node_delete_prob:
            # Initialize dictionaries for outgoing and incoming connections
            outgoing_connections = {}
            incoming_connections = {}

            # Count connections and store connected nodes
            for connection in self.connections:
                from_node = connection['from']
                to_node = connection['to']

                if from_node not in outgoing_connections:
                    outgoing_connections[from_node] = {'count': 0, 'to_nodes': []}
                outgoing_connections[from_node]['count'] += 1
                outgoing_connections[from_node]['to_nodes'].append(to_node)

                if to_node not in incoming_connections:
                    incoming_connections[to_node] = {'count': 0, 'from_nodes': []}
                incoming_connections[to_node]['count'] += 1
                incoming_connections[to_node]['from_nodes'].append(from_node)


            # Check node 8 based on the given conditions
            valid_to_delete = []

            for node_id_to_check in range(self.num_inputs+1,self.nodes[-1][-1]["id"]-self.num_outputs+1):
                # Get the inputs of the given ID
                input_nodes = incoming_connections[node_id_to_check]['from_nodes']
                # Check if any input node has less than 2 outputs
                all_have_at_least_two_outputs = all(outgoing_connections[node]['count'] >= 2 for node in input_nodes)
                # Get the outputs of the given ID
                output_nodes = outgoing_connections[node_id_to_check]['to_nodes']
                # Check if any output node has less than 2 inputs
                all_have_at_least_two_inputs = all(incoming_connections[node]['count'] >= 2 for node in output_nodes)

                if all_have_at_least_two_inputs and all_have_at_least_two_outputs:
                    valid_to_delete.append(node_id_to_check)



            if len(valid_to_delete) > 0:
                node_to_delete = random.choice(valid_to_delete)
                for layer in self.nodes:
                    for node in layer:
                        if node.get('id') == node_to_delete:
                            layer.remove(node)
                            break
                self.connections =  [conn for conn in self.connections if conn['from'] != node_to_delete and conn['to'] != node_to_delete]
                self.clean_ids()

        #delete connection
        if random.uniform(0,1) <= self.conn_delete_prob:
            options = self.connections.copy()

            while len(options) > 0:
                temp_conn = random.choice(options)

                from_node1 = 0
                to_node1 = 0
                for i in self.connections:
                    if i["from"] == temp_conn["from"]:
                        from_node1+=1
                    if i["to"] == temp_conn["to"]:
                        to_node1+=1
                if from_node1 > 1 and to_node1 > 1:
                    break
                else:
                    options.remove(temp_conn)


            if len(options) > 0:
                self.connections.remove(temp_conn)

        #add connection
        if random.uniform(0,1) <= self.conn_add_prob:
            # Extract existing connections
            existing_connections = {(conn['from'], conn['to']) for conn in self.connections}

            # Generate all possible connections between adjacent layers
            all_connections = []
            for i in range(len(self.nodes) - 1):
                for node_from in self.nodes[i]:
                    for node_to in self.nodes[i + 1]:
                        if (node_from['id'], node_to['id']) not in existing_connections:
                            all_connections.append((node_from['id'], node_to['id']))
            if len(all_connections) > 0:
                conn_to_add = random.choice(all_connections)
                self.connections.append({"from": conn_to_add[0], "to": conn_to_add[1],"weight": random.uniform(self.weight_min_value, self.weight_max_value)})

    def clean_ids(self):
        id = 1
        swaps = []
        for x in self.nodes:
            for y in x:
                if y["id"] != id:
                    swaps.append({y["id"]: id})
                y["id"] = id
                id+=1
        swaps = {k: v for pair in swaps for k, v in pair.items()}

        for edge in self.connections:
            if edge['from'] in swaps:
                edge['from'] = swaps[edge['from']]
            if edge['to'] in swaps:
                edge['to'] = swaps[edge['to']]




class population:
    def __init__(self, config_file, pop_zise):
        self.pop_zise = pop_zise
        self.bots = []
        for i in range(self.pop_zise):
            self.bots.append(neural_network(config_file))

    def add_inputs(self, num_inputs):
        for i in self.bots:
            i.add_inputs(num_inputs)


    def add_layer(self, nodes):
        for i in self.bots:
            i.add_layer(nodes)

    def add_outputs(self, num_outputs):
        for i in self.bots:
            i.add_outputs(num_outputs)


    def active(self ,*args, index="all"):
        if index == "all":
            for i in self.bots:
                i.active(*args)
        else:
            self.bots[index].active(*args)

    def plot(self, id):
        self.bots[id].plot()


    def select_parents(self):
        weights = [x.fitness for x in self.bots]

        chosen_parents = []
        while len(chosen_parents) != 4:
            temp_bot =  random.choices(self.bots, weights=weights, k=1)[0]
            if temp_bot not in chosen_parents:
                chosen_parents.append(temp_bot)
        return chosen_parents




    def best_bot(self):
        best_index = 0
        best_fitness = self.bots[0].fitness
        best_bot_class = 0
        for index, bot in enumerate(self.bots):
            if bot.fitness >= best_fitness:
                best_index = index
                best_fitness = bot.fitness
                best_bot_class = bot

        return best_bot_class ,best_index, best_fitness



    def mutate(self):
        for i in self.bots[5:]:
            i.mutate()