import graphviz


def plot_ai(nodes,connections):
    # Create a new directed graph
    dot = graphviz.Digraph()

    # Define a consistent size for all nodes
    node_size = '1.2'

    # Add nodes with circular shape and consistent size
    for layer in nodes:
        for node in layer:
            node_id = node['id']
            label = f"ID {node_id}\n"
            if 'bias' in node:
                label += f"{node['activation']}\n{node['aggregation']}"
            dot.node(str(node['id']), label, shape='circle', width=node_size, height=node_size, fixedsize='true')

    # Add edges with colors based on weight
    for connection in connections:
        from_node = str(connection['from'])
        to_node = str(connection['to'])
        weight = connection['weight']

        # Determine color based on weight
        if weight > 0:
            color = 'green'
        else:
            color = 'red'

        dot.edge(from_node, to_node, color=color)


    # Render and view the graph
    dot.render('graphviz/neural_network_graph_weighted', format='png', cleanup=True)
    dot.view()
