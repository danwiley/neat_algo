import gym
from model_lib.main import population
import copy

# Create the CartPole-v1 environment with human render mode
#env = gym.make('CarRacing-v2', render_mode='human')
env = gym.make('CartPole-v1')

# Reset the environment to the initial state

state = env.reset()[0]

AI = population('config.ini', 100)
AI.add_inputs(4)
AI.add_layer(1)
AI.add_layer(1)
AI.add_outputs(1)
fitness = 0
while fitness < 2000:
    for i,bot in enumerate(AI.bots):
        score = 0
        # Number of steps to run in the environment
        while True:
            # Render the environment (this will show the graphical representation)
            env.render()

            AI.active(*tuple(state)[:4],index=i)
            action = bot.final_output[0]
            # Apply the action to the environment and get the new state and reward
            next_state, reward, terminated, truncated, info = env.step(action)
            score += reward


            state = next_state

            # If the episode is terminated or truncated, reset the environment
            if score > 2000 or terminated:
                bot.fitness = score if score >=1 else 1
                state = env.reset()[0]
                break
    best , _, fitness = AI.best_bot()

    for b in range(len(AI.bots)):
        AI.bots[b] = copy.deepcopy(best)
    if fitness <2000:
        AI.mutate()

    print(fitness)



env = gym.make('CartPole-v1', render_mode='human')
state = env.reset()[0]
_, best_index, _ = AI.best_bot()
AI.plot(best_index)
while True:
    # Render the environment (this will show the graphical representation)
    env.render()

    AI.active(*tuple(state)[:4], index=best_index)
    action = AI.bots[best_index].final_output[0]
    # Apply the action to the environment and get the new state and reward
    next_state, reward, terminated, truncated, info = env.step(action)

    state = next_state

    # If the episode is terminated or truncated, reset the environment
    if terminated or truncated:
        break



env.close()

